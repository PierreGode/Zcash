sudo mkdir /etc/systemd/system/zcash
sudo mkdir /var/zcmine/
sudo cp miner* /var/zcmine/
sudo cp Zec.service /etc/systemd/system/zcash/
sudo systemctl daemon-reload
sudo systemctl enable Zec.service
sudo systemctl start Zec.service
